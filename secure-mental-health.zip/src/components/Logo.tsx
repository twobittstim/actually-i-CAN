import React from 'react';
import { Heart, Shield } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div className="p-2 bg-white/20 rounded-lg">
          <Shield className="w-6 h-6" />
        </div>
        <Heart className="w-3 h-3 text-pink-300 absolute -top-1 -right-1" />
      </div>
      <div>
        <h1 className="text-2xl font-bold">SecureSpace</h1>
        <p className="text-xs text-indigo-100 opacity-90">Mental Health Companion</p>
      </div>
    </div>
  );
};

export default Logo;