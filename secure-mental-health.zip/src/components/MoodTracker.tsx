import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar, TrendingUp, Heart, Brain } from 'lucide-react';

interface MoodEntry {
  id: string;
  date: string;
  mood: number;
  anxiety: number;
  energy: number;
  notes: string;
}

const MoodTracker: React.FC = () => {
  const [currentMood, setCurrentMood] = useState([5]);
  const [currentAnxiety, setCurrentAnxiety] = useState([5]);
  const [currentEnergy, setCurrentEnergy] = useState([5]);
  const [notes, setNotes] = useState('');
  const [entries, setEntries] = useState<MoodEntry[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('mood-entries');
    if (saved) {
      setEntries(JSON.parse(saved));
    }
  }, []);

  const saveMoodEntry = () => {
    const newEntry: MoodEntry = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString(),
      mood: currentMood[0],
      anxiety: currentAnxiety[0],
      energy: currentEnergy[0],
      notes
    };
    
    const updatedEntries = [newEntry, ...entries].slice(0, 30);
    setEntries(updatedEntries);
    localStorage.setItem('mood-entries', JSON.stringify(updatedEntries));
    
    setNotes('');
    setCurrentMood([5]);
    setCurrentAnxiety([5]);
    setCurrentEnergy([5]);
  };

  const getMoodColor = (value: number) => {
    if (value <= 3) return 'text-red-400';
    if (value <= 6) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getMoodLabel = (value: number) => {
    if (value <= 2) return 'Very Low';
    if (value <= 4) return 'Low';
    if (value <= 6) return 'Moderate';
    if (value <= 8) return 'Good';
    return 'Excellent';
  };

  return (
    <div className="space-y-6">
      {/* Current Mood Entry */}
      <Card className="bg-black/40 border-red-500 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-400">
            <Heart className="w-5 h-5" />
            How are you feeling today?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-red-200 mb-2 block">
                Overall Mood: {getMoodLabel(currentMood[0])}
              </label>
              <Slider
                value={currentMood}
                onValueChange={setCurrentMood}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>Very Low</span>
                <span>Excellent</span>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-red-200 mb-2 block">
                Anxiety Level: {getMoodLabel(currentAnxiety[0])}
              </label>
              <Slider
                value={currentAnxiety}
                onValueChange={setCurrentAnxiety}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-red-200 mb-2 block">
                Energy Level: {getMoodLabel(currentEnergy[0])}
              </label>
              <Slider
                value={currentEnergy}
                onValueChange={setCurrentEnergy}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-red-200 mb-2 block">
                Notes (optional)
              </label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="How was your day? Any thoughts or feelings you'd like to record?"
                className="bg-gray-800 border-red-500 text-white placeholder-gray-400"
                rows={3}
              />
            </div>
          </div>

          <Button 
            onClick={saveMoodEntry}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
          >
            Save Entry
          </Button>
        </CardContent>
      </Card>

      {/* Recent Entries */}
      <Card className="bg-black/40 border-red-500 text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-400">
            <TrendingUp className="w-5 h-5" />
            Recent Entries
          </CardTitle>
        </CardHeader>
        <CardContent>
          {entries.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              No mood entries yet. Start tracking your mood above!
            </p>
          ) : (
            <div className="space-y-4">
              {entries.slice(0, 10).map((entry) => (
                <div key={entry.id} className="border border-red-500/30 rounded-lg p-4 bg-gray-900/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-red-200">{entry.date}</span>
                    <div className="flex gap-2">
                      <Badge variant="outline" className={`border-red-500 ${getMoodColor(entry.mood)}`}>
                        Mood: {entry.mood}/10
                      </Badge>
                      <Badge variant="outline" className={`border-red-500 ${getMoodColor(11 - entry.anxiety)}`}>
                        Anxiety: {entry.anxiety}/10
                      </Badge>
                      <Badge variant="outline" className={`border-red-500 ${getMoodColor(entry.energy)}`}>
                        Energy: {entry.energy}/10
                      </Badge>
                    </div>
                  </div>
                  {entry.notes && (
                    <p className="text-sm text-gray-300 mt-2">{entry.notes}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default MoodTracker;