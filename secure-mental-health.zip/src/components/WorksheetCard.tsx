import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Edit, Trash2, Calendar } from 'lucide-react';

interface Worksheet {
  id: string;
  title: string;
  category: string;
  lastModified: Date;
  entries: number;
  content?: string;
  notes?: string;
}

interface WorksheetCardProps {
  worksheet: Worksheet;
  onEdit: (id: string) => void;
  onDelete?: (id: string) => void;
}

const WorksheetCard: React.FC<WorksheetCardProps> = ({ worksheet, onEdit, onDelete }) => {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Card className="bg-gray-900/50 border-red-500/30 text-white hover:border-red-400 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-red-400" />
            <CardTitle className="text-red-200 text-lg">{worksheet.title}</CardTitle>
          </div>
          <Badge variant="outline" className="border-red-500 text-red-300">
            {worksheet.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          {worksheet.content && (
            <p className="text-sm text-gray-300 line-clamp-2">
              {worksheet.content}
            </p>
          )}
          
          <div className="flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {formatDate(worksheet.lastModified)}
              </span>
              <span>{worksheet.entries} entries</span>
            </div>
          </div>
          
          {worksheet.notes && (
            <p className="text-xs text-gray-400 italic">
              "{worksheet.notes}"
            </p>
          )}
          
          <div className="flex gap-2 pt-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onEdit(worksheet.id)}
              className="border-red-500 text-red-300 hover:bg-red-600 hover:text-white flex-1"
            >
              <Edit className="w-3 h-3 mr-1" />
              Edit
            </Button>
            {onDelete && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onDelete(worksheet.id)}
                className="border-red-500 text-red-300 hover:bg-red-700 hover:text-white"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorksheetCard;