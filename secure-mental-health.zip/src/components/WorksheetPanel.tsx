import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Plus, Download, Upload } from 'lucide-react';
import WorksheetCard from './WorksheetCard';
import WorksheetForm from './WorksheetForm';
import PDFUpload from './PDFUpload';

interface Worksheet {
  id: string;
  title: string;
  category: string;
  lastModified: Date;
  entries: number;
  content?: string;
  notes?: string;
}

const WorksheetPanel: React.FC = () => {
  const [worksheets, setWorksheets] = useState<Worksheet[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingWorksheet, setEditingWorksheet] = useState<Worksheet | null>(null);
  const [showPDFUpload, setShowPDFUpload] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('worksheets');
    if (saved) {
      setWorksheets(JSON.parse(saved));
    } else {
      // Default worksheets
      const defaultWorksheets = [
        {
          id: '1',
          title: 'Daily Mood Journal',
          category: 'Mood Tracking',
          lastModified: new Date(),
          entries: 0,
          content: 'Track your daily emotions and thoughts',
          notes: ''
        },
        {
          id: '2',
          title: 'Anxiety Coping Strategies',
          category: 'Coping Skills',
          lastModified: new Date(),
          entries: 0,
          content: 'List and practice anxiety management techniques',
          notes: ''
        },
        {
          id: '3',
          title: 'Gratitude Practice',
          category: 'Positive Psychology',
          lastModified: new Date(),
          entries: 0,
          content: 'Daily gratitude reflection and appreciation',
          notes: ''
        }
      ];
      setWorksheets(defaultWorksheets);
      localStorage.setItem('worksheets', JSON.stringify(defaultWorksheets));
    }
  }, []);

  const handleSaveWorksheet = (worksheetData: any) => {
    let updatedWorksheets;
    if (editingWorksheet) {
      updatedWorksheets = worksheets.map(w => w.id === editingWorksheet.id ? worksheetData : w);
    } else {
      updatedWorksheets = [...worksheets, worksheetData];
    }
    setWorksheets(updatedWorksheets);
    localStorage.setItem('worksheets', JSON.stringify(updatedWorksheets));
    setShowForm(false);
    setEditingWorksheet(null);
  };

  const handleEditWorksheet = (id: string) => {
    const worksheet = worksheets.find(w => w.id === id);
    if (worksheet) {
      setEditingWorksheet(worksheet);
      setShowForm(true);
    }
  };

  const handleDeleteWorksheet = (id: string) => {
    const updatedWorksheets = worksheets.filter(w => w.id !== id);
    setWorksheets(updatedWorksheets);
    localStorage.setItem('worksheets', JSON.stringify(updatedWorksheets));
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingWorksheet(null);
  };

  const handlePDFUpload = (file: File) => {
    const newWorksheet: Worksheet = {
      id: Date.now().toString(),
      title: file.name.replace('.pdf', ''),
      category: 'PDF Worksheet',
      lastModified: new Date(),
      entries: 0,
      content: `PDF worksheet: ${file.name}`,
      notes: 'Uploaded PDF worksheet'
    };
    
    const updatedWorksheets = [...worksheets, newWorksheet];
    setWorksheets(updatedWorksheets);
    localStorage.setItem('worksheets', JSON.stringify(updatedWorksheets));
    setShowPDFUpload(false);
  };

  if (showForm) {
    return (
      <WorksheetForm 
        onSave={handleSaveWorksheet}
        onCancel={handleCancel}
        initialData={editingWorksheet}
      />
    );
  }

  if (showPDFUpload) {
    return (
      <PDFUpload 
        onUpload={handlePDFUpload}
        onCancel={() => setShowPDFUpload(false)}
      />
    );
  }

  return (
    <Card className="h-full bg-black/40 border-red-500 text-white">
      <CardHeader>
        <CardTitle className="text-red-400 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Mental Health Worksheets
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-red-300">Your Worksheets</h3>
            <div className="flex gap-2">
              <Button 
                onClick={() => setShowPDFUpload(true)}
                variant="outline"
                className="border-red-500 text-red-300 hover:bg-red-600 hover:text-white"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload PDF
              </Button>
              <Button 
                onClick={() => setShowForm(true)}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Worksheet
              </Button>
            </div>
          </div>
          
          <ScrollArea className="h-[500px] pr-4">
            <div className="grid gap-4">
              {worksheets.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No worksheets yet. Create your first worksheet!</p>
                </div>
              ) : (
                worksheets.map((worksheet) => (
                  <WorksheetCard 
                    key={worksheet.id} 
                    worksheet={worksheet} 
                    onEdit={handleEditWorksheet}
                    onDelete={handleDeleteWorksheet}
                  />
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorksheetPanel;