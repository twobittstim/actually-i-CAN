import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Users, MessageSquare, Eye, EyeOff } from 'lucide-react';

interface Message {
  id: string;
  user_id: string;
  content: string;
  is_from_user: boolean;
  created_at: string;
}

interface UserStats {
  user_id: string;
  message_count: number;
  last_message: string;
}

export const AdminPanel: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [userStats, setUserStats] = useState<UserStats[]>([]);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const { data: messagesData } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (messagesData) {
        setMessages(messagesData);
        
        // Calculate user stats
        const stats: { [key: string]: UserStats } = {};
        messagesData.forEach(msg => {
          if (!stats[msg.user_id]) {
            stats[msg.user_id] = {
              user_id: msg.user_id,
              message_count: 0,
              last_message: msg.created_at
            };
          }
          stats[msg.user_id].message_count++;
          if (msg.created_at > stats[msg.user_id].last_message) {
            stats[msg.user_id].last_message = msg.created_at;
          }
        });
        
        setUserStats(Object.values(stats));
      }
    } catch (error) {
      console.error('Error loading admin data:', error);
    }
  };

  const userMessages = selectedUser 
    ? messages.filter(m => m.user_id === selectedUser)
    : [];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-[600px]">
      <Card className="bg-gray-900 border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-400">
            <Users className="w-5 h-5" />
            User Overview ({userStats.length} users)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {userStats.map(user => (
              <div 
                key={user.user_id}
                className={`p-3 mb-2 rounded cursor-pointer border ${
                  selectedUser === user.user_id 
                    ? 'bg-red-900/30 border-red-600' 
                    : 'bg-gray-800 border-red-700 hover:bg-gray-700'
                }`}
                onClick={() => setSelectedUser(user.user_id)}
              >
                <div className="flex justify-between items-center">
                  <span className="text-gray-200 text-sm font-mono">
                    {user.user_id.substring(0, 20)}...
                  </span>
                  <Badge variant="secondary" className="bg-red-800 text-red-200">
                    {user.message_count}
                  </Badge>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Last: {new Date(user.last_message).toLocaleDateString()}
                </p>
              </div>
            ))}
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-red-400">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Messages {selectedUser && `(${userMessages.length})`}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowContent(!showContent)}
              className="text-red-300 hover:bg-red-900/30"
            >
              {showContent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {!selectedUser ? (
              <p className="text-center text-gray-400 mt-8">
                Select a user to view their messages
              </p>
            ) : (
              userMessages.map(message => (
                <div
                  key={message.id}
                  className={`mb-3 p-3 rounded-lg ${
                    message.is_from_user
                      ? 'bg-red-800/30 border-l-4 border-red-600'
                      : 'bg-gray-700/50 border-l-4 border-gray-500'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant={message.is_from_user ? 'destructive' : 'secondary'}>
                      {message.is_from_user ? 'User' : 'Admin'}
                    </Badge>
                    <span className="text-xs text-gray-400">
                      {new Date(message.created_at).toLocaleString()}
                    </span>
                  </div>
                  {showContent ? (
                    <p className="text-gray-200 text-sm">{message.content}</p>
                  ) : (
                    <p className="text-gray-400 text-sm italic">
                      [Content hidden - click eye icon to view]
                    </p>
                  )}
                </div>
              ))
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};