import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, FileText, X, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PDFUploadProps {
  onUpload: (file: File) => void;
  onCancel: () => void;
}

const PDFUpload: React.FC<PDFUploadProps> = ({ onUpload, onCancel }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string>('');

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFileSelection(files[0]);
    }
  }, []);

  const handleFileSelection = (file: File) => {
    setError('');
    
    if (file.type !== 'application/pdf') {
      setError('Please select a PDF file only.');
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError('File size must be less than 10MB.');
      return;
    }
    
    setSelectedFile(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFileSelection(files[0]);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      onUpload(selectedFile);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="bg-black/40 border-red-500 text-white">
      <CardHeader>
        <CardTitle className="text-red-400 flex items-center gap-2">
          <Upload className="w-5 h-5" />
          Upload PDF Worksheet
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert className="border-red-500 bg-red-900/20">
            <AlertCircle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-red-200">
              {error}
            </AlertDescription>
          </Alert>
        )}

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragActive 
              ? 'border-red-400 bg-red-900/20' 
              : 'border-red-500/50 hover:border-red-400'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <div className="space-y-4">
            <div className="mx-auto w-12 h-12 text-red-400">
              <FileText className="w-full h-full" />
            </div>
            
            {selectedFile ? (
              <div className="space-y-2">
                <p className="text-red-200 font-medium">{selectedFile.name}</p>
                <p className="text-sm text-gray-400">
                  {formatFileSize(selectedFile.size)}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFile(null)}
                  className="border-red-500 text-red-300 hover:bg-red-600"
                >
                  Remove
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-red-200">
                  Drag and drop your PDF here, or click to browse
                </p>
                <p className="text-sm text-gray-400">
                  Maximum file size: 10MB
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="file-input" className="text-red-200">
            Or choose file:
          </Label>
          <Input
            id="file-input"
            type="file"
            accept=".pdf"
            onChange={handleFileInput}
            className="bg-gray-800 border-red-500 text-white file:bg-red-600 file:text-white file:border-0 file:rounded file:px-3 file:py-1"
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            onClick={handleUpload}
            disabled={!selectedFile}
            className="bg-red-600 hover:bg-red-700 text-white flex-1 disabled:opacity-50"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Worksheet
          </Button>
          <Button
            variant="outline"
            onClick={onCancel}
            className="border-red-500 text-red-300 hover:bg-red-600 hover:text-white"
          >
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PDFUpload;