import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://vvedufkksgfcfvhbirgm.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ2ZWR1Zmtrc2dmY2Z2aGJpcmdtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEwMTU4ODMsImV4cCI6MjA2NjU5MTg4M30.VCyhEf9qKRqmRx-sAj3d9xK-WnL4oZLV_AcUh8Dd3fk';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };