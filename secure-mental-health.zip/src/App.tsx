import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import { PhoneAuth } from '@/components/PhoneAuth';
import { SecureMessaging } from '@/components/SecureMessaging';
import { AdminPanel } from '@/components/AdminPanel';
import { ShareApp } from '@/components/ShareApp';
import { DisclosureDialog } from '@/components/DisclosureDialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ExternalLink, Heart, Shield, Settings, Share2, Users } from 'lucide-react';
import './App.css';

const queryClient = new QueryClient();

function App() {
  const [userId, setUserId] = useState<string | null>(null);
  const [showDisclosure, setShowDisclosure] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleAuthSuccess = (id: string) => {
    setUserId(id);
    // Check if admin (you can customize this logic)
    setIsAdmin(id.includes('admin') || id === 'user_admin_123');
  };

  const handleLogout = () => {
    setUserId(null);
    setIsAdmin(false);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-red-950">
            <header className="bg-gradient-to-r from-black to-red-900 text-white p-4 border-b border-red-800">
              <div className="container mx-auto flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="p-2 bg-red-900/30 rounded-lg border border-red-700">
                      <Shield className="w-6 h-6 text-red-400" />
                    </div>
                    <Heart className="w-3 h-3 text-red-300 absolute -top-1 -right-1" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-red-400">SecureSpace</h1>
                    <p className="text-xs text-gray-300 opacity-90">Mental Health Companion</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowDisclosure(true)}
                    className="text-red-300 hover:bg-red-900/30 hover:text-red-200"
                  >
                    Privacy & Safety
                  </Button>
                  {userId && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleLogout}
                      className="bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/40"
                    >
                      Logout
                    </Button>
                  )}
                </div>
              </div>
            </header>

            <main className="container mx-auto p-4">
              {!userId ? (
                <div className="max-w-md mx-auto mt-8">
                  <PhoneAuth onAuthSuccess={handleAuthSuccess} />
                  <div className="mt-8 text-center">
                    <Card className="bg-gray-900 border-red-800">
                      <CardHeader>
                        <CardTitle className="text-red-400">Learn More</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Button
                          variant="outline"
                          className="w-full bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/40"
                          onClick={() => window.open('https://addiction--recovery.blogspot.com/?m=1', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Visit My Blog
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/40"
                          onClick={() => window.open('https://www.twelch.com/', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Visit My Website
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ) : (
                <div className="max-w-6xl mx-auto mt-8">
                  {isAdmin ? (
                    <Tabs defaultValue="messaging" className="w-full">
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800 border-red-700">
                        <TabsTrigger value="messaging" className="data-[state=active]:bg-red-800">
                          <Settings className="w-4 h-4 mr-2" />
                          Messaging
                        </TabsTrigger>
                        <TabsTrigger value="admin" className="data-[state=active]:bg-red-800">
                          <Users className="w-4 h-4 mr-2" />
                          Admin Panel
                        </TabsTrigger>
                        <TabsTrigger value="share" className="data-[state=active]:bg-red-800">
                          <Share2 className="w-4 h-4 mr-2" />
                          Share App
                        </TabsTrigger>
                      </TabsList>
                      <TabsContent value="messaging" className="mt-6">
                        <SecureMessaging userId={userId} />
                      </TabsContent>
                      <TabsContent value="admin" className="mt-6">
                        <AdminPanel />
                      </TabsContent>
                      <TabsContent value="share" className="mt-6">
                        <ShareApp />
                      </TabsContent>
                    </Tabs>
                  ) : (
                    <SecureMessaging userId={userId} />
                  )}
                </div>
              )}
            </main>

            <DisclosureDialog
              open={showDisclosure}
              onOpenChange={setShowDisclosure}
            />
          </div>
        </Router>
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;